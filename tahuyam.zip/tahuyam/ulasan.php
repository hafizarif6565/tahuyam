<?php

include "admin/koneksi.php";

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tahuyam | Tahu Isi Ayam</title>

    <!-- CSS FILES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200;0,400;0,600;0,700;1,200;1,700&display=swap"
        rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/bootstrap-icons.css" rel="stylesheet">

    <link href="css/vegas.min.css" rel="stylesheet">

    <link href="css/tooplate-barista.css" rel="stylesheet">

    <style>
        #text-turncated{
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

    </style>
    <!--

Tooplate 2137 Barista

https://www.tooplate.com/view/2137-barista-cafe

Bootstrap 5 HTML CSS Template

-->
</head>

<body class="reservation-page">

    <main>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center" href="index.php">
                    <img src="images/tahuyam.png" class="navbar-brand-image" alt="Barista Cafe Template">
                    Tahuyam
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="index.php">Home</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_2">Tentang</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_3">Menu</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_4">Ulasan</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_5">Kontak</a>
                        </li>
                    </ul>

                    <div class="ms-lg-3">
                        <a class="btn custom-btn custom-border-btn"
                            href="https://wa.me/6285362582861?text=Halo,%20saya%20mau%20pesan%20tahu%20isi%20ayam%20pedas!"
                            target="_blank">
                            Preorder
                            <i class="bi-arrow-up-right ms-2"></i>
                        </a>
                    </div>
                </div>
            </div>
        </nav>


        <section class="booking-section section-padding mt-5">
            <div class="container">
                <div class="row">
                    <h2 class="text-center text-white">Ulasan Pelanggan</h2>
                </div>
                <div class="row justify-content-between my-5">
                    <?php
                    $limit = 10;
                    $page = isset($_GET["page"]) ? $_GET["page"] : 1;
                    $start = ($page > 1) ? ($page * $limit) / $limit : 0;
                    $query = mysqli_query($conn, "SELECT * FROM ulasan LIMIT $start, $limit");

                    $totalQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM ulasan");
                    $rTotal = mysqli_fetch_assoc($totalQuery);
                    $pages = ceil($rTotal["total"] / $limit);
                    $no = 1;
                    while ($r = mysqli_fetch_assoc($query)) {
                    ?>
                        <div class="col-lg-4 col-10 mx-auto">
                            <div class="timeline-content">
                                <div class="reviews-block" style="height: 65vh;">
                                    <div class="reviews-block-image-wrap d-flex align-items-center">
                                        <img src="images/reviews/<?php echo $r['foto']; ?>" class="reviews-block-image img-fluid" alt="">

                                        <div class="review-text">
                                            <h6 class="text-white mb-0"><?php echo $r['namaLengkap']; ?></h6>
                                            <em class="text-white"> Customers</em>
                                        </div>
                                    </div>
                                    
                                    <div class="reviews-block-info">
                                        <p class="card-text"><small class="text-body-secondary"><?php echo $r['tanggal']; ?></small></p>
                                        <p id="text-turncated"><?php echo $r['ulasan']; ?></p>

                                        <div class="d-flex border-top pt-3 mt-4">
                                            <strong class="text-white"><?php echo $r['rating']; ?><small class="ms-2">Rating</small></strong>

                                            <div class="reviews-group ms-auto">
                                                <?php
                                                $a = 1;
                                                while ($a <= $r["rating"]) {
                                                ?>
                                                    <i class="bi-star-fill"></i>
                                                <?php $a++;
                                                } ?>
                                                <?php
                                                $b = 1;
                                                while ($b <= 5 - $r["rating"]) {
                                                ?>
                                                    <i class="bi-star"></i>
                                                <?php $b++;
                                                } ?>
                                            </div>
                                        </div>
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#lihat<?php echo $r["idUlasan"]; ?>">
                                            Lihat
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="lihat<?php echo $r["idUlasan"]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Detail Ulasan</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form enctype="multipart/form-data" method="post" action="" id="form" class="w-100 px-4">
                                            <input type="hidden" name="idUlasan" value="<?php echo $r['idUlasan']; ?>">
                                            <label for="" class="form-label">Nama Lengkap : </label>
                                            <input type="text" id="" class="form-control " readonly value="<?php echo $r['namaLengkap']; ?>" name="namaLengkap">
                                            <label for="" class="form-label mt-3">Ulasan : </label>
                                            <textarea name="ulasan" readonly class="form-control" id=""><?php echo $r['ulasan']; ?></textarea>
                                            <label for="" class="form-label mt-3">Rating : </label>
                                            <div class="form-control">
                                                <input type="radio" disabled name="rating" value="1" <?php echo ($r['rating']) == 1 ? "checked" : ""; ?> id="satu"><i class="bi bi-star-fill"></i><label for="satu" class="me-2 text-warning">1</label>
                                                <input type="radio" disabled name="rating" value="2" <?php echo ($r['rating']) == 2 ? "checked" : ""; ?> id="dua"><i class="bi bi-star-fill"></i><label for="dua" class="me-2 text-warning">2</label>
                                                <input type="radio" disabled name="rating" value="3" id="tiga" <?php echo ($r['rating']) == 3 ? "checked" : ""; ?>><i class="bi bi-star-fill"></i><label for="tiga" class="me-2 text-warning">3</label>
                                                <input type="radio" disabled name="rating" value="4" id="empat" <?php echo ($r['rating']) == 4 ? "checked" : ""; ?>><i class="bi bi-star-fill"></i><label for="empat" class="me-2 text-warning">4</label>
                                                <input type="radio" disabled name="rating" value="5" <?php echo ($r['rating']) == 5 ? "checked" : ""; ?> id="lima"><i class="bi bi-star-fill"></i><label for="lima" class="me-2 text-warning">5</label>
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary form-control" data-bs-dismiss="modal">Close</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <li class="page-item"><a class="page-link <?php echo ($page <= 1) ? 'disabled' : ''; ?>" href="?page=<?php echo $page - 1; ?>">Previous</a></li>
                        <?php
                        $a = $start + 1;
                        while ($a <= $pages) {
                        ?>
                            <li class="page-item"><a class="page-link" href="?page=<?php echo $a; ?>"><?php echo $a; ?></a></li>
                        <?php $a++;
                        } ?>
                        <li class="page-item"><a class="page-link <?php echo ($pages >= $page) ? 'disabled' : ''; ?>" href="?page=<?php echo $page + 1; ?>">Next</a></li>
                    </ul>
                </nav>
        </section>


        <footer class="site-footer">
                    <div class="container">
                        <div class="row">

                            <div class="col-lg-4 col-12 me-auto">

                                <ul class="social-icon mt-4">

                                    <li class="social-icon-item">
                                        <a href="https://wa.me/6285362582861?text=Halo,%20saya%20mau%20pesan%20tahu%20isi%20ayam%20pedas!" class="social-icon-link bi-whatsapp">
                                        </a>
                                    </li>
                                    <li class="social-icon-item">
                                        <a href="https://www.instagram.com/tahuyam" target="_blank" class="social-icon-link bi-instagram">
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="col-lg-3 col-12 mt-4 mb-3 mt-lg-0 mb-lg-0">
                                <em class="text-white d-block mb-4">Contact</em>

                                <p class="d-flex mb-1">
                                    <strong class="me-2">Phone:</strong>
                                    <a href="tel: 305-240-9671" class="site-footer-link">
                                        +62
                                        853-6258-2861
                                    </a>
                                </p>
                            </div>


                            <div class="col-lg-5 col-12">
                                <em class="text-white d-block mb-4">Buka Setiap.</em>

                                <ul class="opening-hours-list">
                                    <li class="d-flex">
                                        Senin - Jum'at
                                        <span class="underline"></span>

                                        <strong>9:00 - 18:00</strong>
                                    </li>

                                    <li class="d-flex">
                                        Sabtu & Minggu
                                        <span class="underline"></span>

                                        <strong>Tutup</strong>
                                    </li>
                                </ul>
                            </div>

                            <div class="col-lg-8 col-12 mt-4">
                                <p class="copyright-text mb-0">Copyright © Barista Cafe 2048 
                                    - Design: <a rel="sponsored" href="https://www.tooplate.com" target="_blank">Tooplate</a></p>
                            </div>
                    </div>
                </footer>
    </main>


    <!-- JAVASCRIPT FILES -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/vegas.min.js"></script>
    <script src="js/custom.js"></script>

</body>

</html>