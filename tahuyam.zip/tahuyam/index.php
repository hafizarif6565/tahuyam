<?php
include "admin/koneksi.php";
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Tahuyam | Tahu Isi Ayam</title>

        <!-- CSS FILES -->                
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200;0,400;0,600;0,700;1,200;1,700&display=swap" rel="stylesheet">
            
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/vegas.min.css" rel="stylesheet">

        <link href="css/tooplate-barista.css" rel="stylesheet">
        
<!--

Tooplate 2137 Barista Cafe

https://www.tooplate.com/view/2137-barista-cafe

Bootstrap 5 HTML CSS Template

-->
    </head>
    
    <body>
                
            <main>
                <nav class="navbar navbar-expand-lg">                
                    <div class="container">
                        <a class="navbar-brand d-flex align-items-center" href="index.html">
                            <img src="images/tahuyam.png" class="navbar-brand-image" alt="Barista Cafe Template">
                            Tahuyam
                        </a>
        
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
        
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav ms-lg-auto">
                                <li class="nav-item">
                                    <a class="nav-link click-scroll" href="#section_1">Home</a>
                                </li>
        
                                <li class="nav-item">
                                    <a class="nav-link click-scroll" href="#section_2">Tentang</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link click-scroll" href="#section_3">Menu</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link click-scroll" href="#section_4">Ulasan</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link click-scroll" href="#section_5">Kontak</a>
                                </li>
                            </ul>

                            <div class="ms-lg-3">
                                <a class="btn custom-btn custom-border-btn" href="https://wa.me/6285362582861?text=Halo,%20saya%20mau%20pesan%20tahu%20isi%20ayam%20pedas!" target="_blank">
                                    Preorder
                                    <i class="bi-arrow-up-right ms-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </nav>


                <section class="hero-section d-flex justify-content-center align-items-center" id="section_1">

                    <div class="container">
                        <div class="row align-items-center">

                            <div class="col-lg-6 col-12 mx-auto">
                                <em class="small-text">Selamat datang di Tahuyam.xyz</em>
                                
                                <h1>Tahuyam</h1>

                                <p class="text-white mb-4 pb-lg-2">
                                    Tahu isi ayam <em>favouritmu</em> ada disini.
                                </p>

                                <a class="btn custom-btn custom-border-btn smoothscroll me-3" href="#section_2">
                                    Tentang Kami
                                </a>

                                <a class="btn custom-btn smoothscroll me-2 mb-2" href="#section_3"><strong>Check Menu</strong></a>
                            </div>

                        </div>
                    </div>

                    <div class="hero-slides"></div>
                </section>


                <section class="about-section section-padding" id="section_2">
                    <div class="section-overlay"></div>
                    <div class="container">
                        <div class="row align-items-center">

                            <div class="col-lg-6 col-12">
                                <div class="ratio ratio-1x1">
                                    <video autoplay="" loop="" muted="" class="custom-video" poster="">
                                        <source src="videos/about.mp4" type="video/mp4">

                                        Your browser does not support the video tag.
                                    </video>

                                    <div class="about-video-info d-flex flex-column">
                                        <h4 class="mt-auto">Kami mulai dari tahun 2025</h4>

                                        <h4>Tahu isi ayam terbaik di Medan.</h4>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-5 col-12 mt-4 mt-lg-0 mx-auto">
                                <em class="text-white">Tahuyam.xyz</em>

                                <h2 class="text-white mb-3">Tahuyam Medan</h2>

                                <p class="text-white">Kami menyajikan tahu isi ayam pedas dengan cita rasa autentik. Tahu goreng renyah diisi dengan campuran ayam cincang berbumbu pedas menggoda, cocok untuk camilan atau lauk makan. Dibuat dari bahan segar pilihan tanpa pengawet, siap memuaskan lidah pecinta pedas!
                                </p>

                                <p class="text-white">🔥 Varian Level Pedas: Level 1 (mild) – Level 5 (extra hot)</p>
                                <p class="text-white">📌 Sedia Juga: Tahu original, tahu keju, dan paket combo</p>
                                <p class="text-white">🛵 Saat ini hanya khusus wilayah Kota Medan</p>


                                <p class="text-white">Pesan sekarang dan rasakan ledakan rasa pedasnya! Hubungi kami via WhatsApp. <a rel="nofollow" href="https://wa.me/6285362582861?text=Halo,%20saya%20mau%20pesan%20tahu%20isi%20ayam%20pedas!" target="_blank" target="_blank" class="text-dark fw-bold bg-white p-2 pe-3 rounded-5 mt-2">📲 pesan sekarang</a></p>
                            </div>

                        </div>
                    </div>
                </section>


                <section class="barista-section section-padding section-bg" id="barista-team">
                    <div class="container">
                        <div class="col-lg-12 col-12 text-center mb-4 pb-lg-2">
                            <em class="text-white">Tim Kreatif</em>

                            <h2 class="text-white">Tahuyam</h2>
                        </div>
                        <div class="row justify-content-center flex-wrap-reverse">


                            <div class="col-lg-3 col-md-6 col-12 mb-4">
                                <div class="team-block-wrap">
                                    <div class="team-block-info d-flex flex-column">
                                        <div class="d-flex mt-auto mb-3">
                                            <h4 class="text-white mb-0">Nabila Amriyanti</h4>

                                            <p class="badge ms-4"><em>Owner</em></p>
                                        </div>

                                        <p class="text-white mb-0">Tahu isi ayam fovorit anda ada disini</p>
                                    </div>

                                    <div class="team-block-image-wrap">
                                        <img src="images/team/nabila.jpeg" class="team-block-image img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-12 mb-4">
                                <div class="team-block-wrap">
                                    <div class="team-block-info d-flex flex-column">
                                        <div class="d-flex mt-auto mb-3">
                                            <h4 class="text-white mb-0">Hafiz Irfan Arif</h4>

                                            <p class="badge ms-4"><em>Owner</em></p>
                                        </div>

                                        <p class="text-white mb-0">Tahu isi ayam fovorit anda ada disini</p>
                                    </div>

                                    <div class="team-block-image-wrap">
                                        <img src="images/team/i am.jpeg" class="team-block-image img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-12 mb-4">
                                <div class="team-block-wrap">
                                    <div class="team-block-info d-flex flex-column">
                                        <div class="d-flex mt-auto mb-3">
                                            <h4 class="text-white mb-0">Risti Akila</h4>

                                            <p class="badge ms-4"><em>Owner</em></p>
                                        </div>

                                        <p class="text-white mb-0">Tahu isi ayam fovorit anda ada disini</p>
                                    </div>

                                    <div class="team-block-image-wrap">
                                        <img src="images/team/kila.jpeg" class="team-block-image img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-12 mb-4">
                                <div class="team-block-wrap">
                                    <div class="team-block-info d-flex flex-column">
                                        <div class="d-flex mt-auto mb-3">
                                            <h4 class="text-white mb-0">M. Aldi Ghifari</h4>

                                            <p class="badge ms-4"><em>Owner</em></p>
                                        </div>

                                        <p class="text-white mb-0">Tahu isi ayam fovorit anda ada disini</p>
                                    </div>

                                    <div class="team-block-image-wrap">
                                        <img src="images/team/aldi.jpeg" class="team-block-image img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-12 mb-4">
                                <div class="team-block-wrap">
                                    <div class="team-block-info d-flex flex-column">
                                        <div class="d-flex mt-auto mb-3">
                                            <h4 class="text-white mb-0">Nico Arja Pujaka</h4>

                                            <p class="badge ms-4"><em>Owner</em></p>
                                        </div>

                                        <p class="text-white mb-0">Tahu isi ayam fovorit anda ada disini</p>
                                    </div>

                                    <div class="team-block-image-wrap">
                                        <img src="images/team/niko.jpeg" class="team-block-image img-fluid" alt="">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>


                <section class="menu-section section-padding" id="section_3">
                    <div class="container">
                        <div class="row justify-content-center">

                            <div class="col-lg-6 col-12 mb-4 mb-lg-0">
                                <div class="menu-block-wrap">
                                    <div class="text-center mb-4 pb-lg-2">
                                        <em class="text-white">Delicious Menu</em>
                                        <h4 class="text-white">Breakfast</h4>
                                    </div>

                                    <div class="menu-block">
                                        <div class="d-flex">
                                            <h6>Tahuyam</h6>
                                        
                                            <span class="underline"></span>

                                            <strong class="ms-auto">3k</strong>
                                        </div>

                                        <div class="border-top mt-2 pt-2">
                                            <small>Tahu isi suiran ayam pedas</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>


                <section class="reviews-section section-padding section-bg" id="section_4">
                    <div class="container">
                        <div class="row justify-content-center">

                            <div class="col-lg-12 col-12 text-center mb-4 pb-lg-2">
                                <em class="text-white">Ulasan dari pelanggan</em>

                                <h2 class="text-white">Ulasan</h2>
                            </div>

                            <div class="timeline">
                                <?php
                                $query = mysqli_query($conn, "SELECT * FROM ulasan ORDER BY tanggal DESC LIMIT 3");
                                $no = 1;
                                while($r = mysqli_fetch_assoc($query)){
                                ?>
                                <div class="timeline-container <?php echo ($no % 2 == 0) ? 'timeline-container-right' : 'timeline-container-left'; ?>">
                                    <div class="timeline-content">
                                        <div class="reviews-block">
                                            <div class="reviews-block-image-wrap d-flex align-items-center">
                                                <img src="images/reviews/<?php echo $r["foto"]; ?>" class="reviews-block-image img-fluid" alt="">

                                                <div class="review-text">
                                                    <h6 class="text-white mb-0"><?php echo $r["namaLengkap"]; ?></h6>
                                                    <em class="text-white"> Customers</em>
                                                </div>
                                            </div>

                                            <div class="reviews-block-info">
                                                <p><?php echo $r["ulasan"]; ?></p>

                                                <div class="d-flex border-top pt-3 mt-4">
                                                    <strong class="text-white"><?php echo $r["rating"]; ?><small class="ms-2">Rating</small></strong>

                                                    <div class="reviews-group ms-auto">
                                                        <?php 
                                                        $a = 1;
                                                        while($a <= $r["rating"]){
                                                        ?>
                                                        <i class="bi-star-fill"></i>
                                                        <?php $a++;} ?>
                                                        <?php 
                                                        $b = 1;
                                                        while($b <= 5 - $r["rating"]){
                                                        ?>
                                                        <i class="bi-star"></i>
                                                        <?php $b++;} ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php $no++;} ?>
                            </div>
                            <a href="ulasan.php" class="text-center btn btn-warning text-white w-25 p-3">Lihat Selengkapnya</a>
                        </div>
                    </div>
                </section>


                <section class="contact-section section-padding" id="section_5">
                    <div class="container">
                        <div class="row">   

                            <div class="col-lg-12 col-12">
                                <em class="text-white">Halo, bagaimana pendapatmu</em>
                                <h2 class="text-white mb-4 pb-lg-2">Kontak</h2>
                            </div>

                            <div class="col-lg-6 col-12">
                                <form action="#" method="post" class="custom-form contact-form" role="form">

                                <div class="row">
                                    
                                    <div class="col-lg-6 col-12">
                                        <label for="name" class="form-label">Nama Anda <sup class="text-danger">*</sup></label>

                                        <input type="text" name="name" id="name" class="form-control" placeholder="Budi" required="">
                                    </div>

                                    <div class="col-lg-6 col-12">
                                        <label for="email" class="form-label">Email Anda</label>

                                        <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Budi@gmail.com" required="">
                                    </div>

                                    <div class="col-12">
                                        <label for="message" class="form-label">Bagaimana pendapatmu?</label>

                                        <textarea name="message" rows="4" class="form-control" id="message" placeholder="Pesan Anda" required=""></textarea>
                                        
                                    </div>
                                </div>

                                <div class="col-lg-5 col-12 mx-auto mt-3">
                                    <button type="submit" class="form-control btn btn-outline-warning">Kirim Pesan</button>
                                </div>
                            </form>
                            </div>

                        </div>
                    </div>
                </section>


                <footer class="site-footer">
                    <div class="container">
                        <div class="row">

                            <div class="col-lg-4 col-12 me-auto">

                                <ul class="social-icon mt-4">

                                    <li class="social-icon-item">
                                        <a href="https://wa.me/6285362582861?text=Halo,%20saya%20mau%20pesan%20tahu%20isi%20ayam%20pedas!" class="social-icon-link bi-whatsapp">
                                        </a>
                                    </li>
                                    <li class="social-icon-item">
                                        <a href="https://www.instagram.com/tahuyam" target="_blank" class="social-icon-link bi-instagram">
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="col-lg-3 col-12 mt-4 mb-3 mt-lg-0 mb-lg-0">
                                <em class="text-white d-block mb-4">Contact</em>

                                <p class="d-flex mb-1">
                                    <strong class="me-2">Phone:</strong>
                                    <a href="tel: 305-240-9671" class="site-footer-link">
                                        +62
                                        853-6258-2861
                                    </a>
                                </p>
                            </div>


                            <div class="col-lg-5 col-12">
                                <em class="text-white d-block mb-4">Buka Setiap.</em>

                                <ul class="opening-hours-list">
                                    <li class="d-flex">
                                        Senin - Jum'at
                                        <span class="underline"></span>

                                        <strong>9:00 - 18:00</strong>
                                    </li>

                                    <li class="d-flex">
                                        Sabtu & Minggu
                                        <span class="underline"></span>

                                        <strong>Tutup</strong>
                                    </li>
                                </ul>
                            </div>

                            <div class="col-lg-8 col-12 mt-4">
                                <p class="copyright-text mb-0">Copyright © Barista Cafe 2048 
                                    - Design: <a rel="sponsored" href="https://www.tooplate.com" target="_blank">Tooplate</a></p>
                            </div>
                    </div>
                </footer>
            </main>

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/click-scroll.js"></script>
        <script src="js/vegas.min.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>