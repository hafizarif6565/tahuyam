<?php

error_reporting(0);
include "koneksi.php";
$url = $_GET["url"];
include $url . ".php";

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard | Tahuyam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <style>
        #text-turncated{
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <h1 class="text-center">Dashboard</h1>
        <button type="button" class="btn btn-success my-5" data-bs-toggle="modal" data-bs-target="#tambah">
            Tambah Ulasan
        </button>
        <div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Ulasan</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form enctype="multipart/form-data" action="" method="post" id="form" class="w-100 px-4">
                            <label for="" class="form-label">Nama Lengkap : </label>
                            <input type="text" id="" class="form-control " name="namaLengkap">
                            <label for="" class="form-label mt-3">Foto : </label>
                            <input type="file" id="" name="foto" class="form-control ">
                            <label for="" class="form-label mt-3">Ulasan : </label>
                            <textarea name="ulasan" class="form-control" id=""></textarea>
                            <label for="" class="form-label mt-3">Rating : </label>
                            <div class="form-control">
                                <input type="radio" name="rating" value="1" id="satu"><i class="bi bi-star-fill"></i><label for="satu" class="me-2 text-warning">1</label>
                                <input type="radio" name="rating" value="2" id="dua"><i class="bi bi-star-fill"></i><label for="dua" class="me-2 text-warning">2</label>
                                <input type="radio" name="rating" value="3" id="tiga"><i class="bi bi-star-fill"></i><label for="tiga" class="me-2 text-warning">3</label>
                                <input type="radio" name="rating" value="4" id="empat"><i class="bi bi-star-fill"></i><label for="empat" class="me-2 text-warning">4</label>
                                <input type="radio" name="rating" value="5" id="lima"><i class="bi bi-star-fill"></i><label for="lima" class="me-2 text-warning">5</label>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="tambah" class="btn btn-primary form-control mt-3">Tambah</button>
                        <button type="button" class="btn btn-secondary form-control" data-bs-dismiss="modal">Close</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-between">
            <?php
            $limit = 10;
            $page = isset($_GET["page"]) ? $_GET["page"] : 1;
            $start = ($page > 1) ? ($page * $limit) / $limit : 0;
            $query = mysqli_query($conn, "SELECT * FROM ulasan LIMIT $start, $limit");

            $totalQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM ulasan");
            $rTotal = mysqli_fetch_assoc($totalQuery);
            $pages = ceil($rTotal["total"] / $limit);
            $no = 1;
            while ($r = mysqli_fetch_assoc($query)) {
            ?>
                <div class="col-md-5">
                    <div class="card mb-3">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="../images/reviews/<?php echo $r['foto']; ?>" class="img-fluid rounded-start" alt="foto <?php echo $r['namaLengkap']; ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $r['namaLengkap']; ?></h5>
                                    <p class="card-text" id="text-turncated"><?php echo $r['ulasan']; ?></p>
                                    <p class="card-text"><small class="text-body-secondary"><?php echo $r['tanggal']; ?></small></p>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#lihat<?php echo $r["idUlasan"]; ?>">
                                        Lihat
                                    </button>
                                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#update<?php echo $r["idUlasan"]; ?>">
                                        Update
                                    </button>
                                    <a href="?url=hapus&id=<?php echo $r['idUlasan']; ?>" class="btn btn-danger" onclick="return confirm('Yakin hapus?')">Delete</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="lihat<?php echo $r["idUlasan"]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Detail Ulasan</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form enctype="multipart/form-data" method="post" action="" id="form" class="w-100 px-4">
                                    <input type="hidden" name="idUlasan" value="<?php echo $r['idUlasan']; ?>">
                                    <label for="" class="form-label">Nama Lengkap : </label>
                                    <input type="text" id="" class="form-control " readonly value="<?php echo $r['namaLengkap']; ?>" name="namaLengkap">
                                    <label for="" class="form-label mt-3">Ulasan : </label>
                                    <textarea name="ulasan" readonly class="form-control" id=""><?php echo $r['ulasan']; ?></textarea>
                                    <label for="" class="form-label mt-3">Rating : </label>
                                    <div class="form-control">
                                        <input type="radio" disabled name="rating" value="1" <?php echo ($r['rating']) == 1 ? "checked" : ""; ?> id="satu"><i class="bi bi-star-fill"></i><label for="satu" class="me-2 text-warning">1</label>
                                        <input type="radio" disabled name="rating" value="2" <?php echo ($r['rating']) == 2 ? "checked" : ""; ?> id="dua"><i class="bi bi-star-fill"></i><label for="dua" class="me-2 text-warning">2</label>
                                        <input type="radio" disabled name="rating" value="3" id="tiga" <?php echo ($r['rating']) == 3 ? "checked" : ""; ?>><i class="bi bi-star-fill"></i><label for="tiga" class="me-2 text-warning">3</label>
                                        <input type="radio" disabled name="rating" value="4" id="empat" <?php echo ($r['rating']) == 4 ? "checked" : ""; ?>><i class="bi bi-star-fill"></i><label for="empat" class="me-2 text-warning">4</label>
                                        <input type="radio" disabled name="rating" value="5" <?php echo ($r['rating']) == 5 ? "checked" : ""; ?> id="lima"><i class="bi bi-star-fill"></i><label for="lima" class="me-2 text-warning">5</label>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary form-control" data-bs-dismiss="modal">Close</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="update<?php echo $r["idUlasan"]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Update Ulasan</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form enctype="multipart/form-data" method="post" action="" id="form" class="w-100 px-4">
                                    <input type="hidden" name="idUlasan" value="<?php echo $r['idUlasan']; ?>">
                                    <label for="" class="form-label">Nama Lengkap : </label>
                                    <input type="text" id="" class="form-control " value="<?php echo $r['namaLengkap']; ?>" name="namaLengkap">
                                    <label for="" class="form-label mt-3">Foto : </label>
                                    <input type="file" id="" name="foto" class="form-control ">
                                    <input type="hidden" name="gambar" value="<?php echo $r['foto']; ?>">
                                    <label for="" class="form-label mt-3">Ulasan : </label>
                                    <textarea name="ulasan" class="form-control" id=""><?php echo $r['ulasan']; ?></textarea>
                                    <label for="" class="form-label mt-3">Rating : </label>
                                    <div class="form-control">
                                        <input type="radio" name="rating" value="1" <?php echo ($r['rating']) == 1 ? "checked" : ""; ?> id="satu"><i class="bi bi-star-fill"></i><label for="satu" class="me-2 text-warning">1</label>
                                        <input type="radio" name="rating" value="2" <?php echo ($r['rating']) == 2 ? "checked" : ""; ?> id="dua"><i class="bi bi-star-fill"></i><label for="dua" class="me-2 text-warning">2</label>
                                        <input type="radio" name="rating" value="3" id="tiga" <?php echo ($r['rating']) == 3 ? "checked" : ""; ?>><i class="bi bi-star-fill"></i><label for="tiga" class="me-2 text-warning">3</label>
                                        <input type="radio" name="rating" value="4" id="empat" <?php echo ($r['rating']) == 4 ? "checked" : ""; ?>><i class="bi bi-star-fill"></i><label for="empat" class="me-2 text-warning">4</label>
                                        <input type="radio" name="rating" value="5" <?php echo ($r['rating']) == 5 ? "checked" : ""; ?> id="lima"><i class="bi bi-star-fill"></i><label for="lima" class="me-2 text-warning">5</label>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="update" class="btn btn-success form-control mt-3">Update</button>
                                <button type="button" class="btn btn-secondary form-control" data-bs-dismiss="modal">Close</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <li class="page-item"><a class="page-link <?php echo ($page <= 1) ? 'disabled' : ''; ?>" href="?page=<?php echo $page - 1; ?>">Previous</a></li>
                <?php 
                $a = $start + 1;
                while($a <= $pages) {
                ?>
                <li class="page-item"><a class="page-link" href="?page=<?php echo $a; ?>"><?php echo $a; ?></a></li>
                <?php $a++;} ?>
                <li class="page-item"><a class="page-link <?php echo ($pages >= $page) ? 'disabled' : ''; ?>" href="?page=<?php echo $page + 1; ?>">Next</a></li>
            </ul>
        </nav>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>

</html>
<?php

$namaLengkap = $_POST["namaLengkap"];
$ulasan = $_POST["ulasan"];
$date = date("Y-m-d");
$foto = $_FILES["foto"]["name"];
$tmp_name = $_FILES["foto"]["tmp_name"];
$letak = "../images/reviews/" . $foto;
$rating = $_POST["rating"];
$idUlasan = $_POST["idUlasan"];

move_uploaded_file($tmp_name, $letak);
$update_foto = isset($foto) ? $foto : $_POST["gambar"];

if (isset($_POST["update"])) {
    mysqli_query($conn, "UPDATE ulasan SET namaLengkap='$namaLengkap', ulasan='$ulasan', tanggal='$date', foto='$update_foto', rating = '$rating' WHERE idUlasan='$idUlasan'");
?>
    <script>
        alert("Data Berhasil diedit");
    </script>
<?php
} elseif (isset($_POST["tambah"])) {
    mysqli_query($conn, "INSERT INTO ulasan(namaLengkap, ulasan, tanggal, foto, rating) VALUES ('$namaLengkap', '$ulasan', '$date', '$foto', '$rating')");
?>
    <script>
        alert("Data Berhasil ditambahkan");
    </script>
<?php
}

?>