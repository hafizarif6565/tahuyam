<?php

$get_id = $_GET["id"];
mysqli_query($conn, "DELETE FROM ulasan WHERE idUlasan='$get_id'");

?>
<script>
    window.location = "dashboard.php";
</script>